ssh 10.235.40.2 'hostname ; . /home/oracle/.bash_profile ; sqlplus -s / as sysdba @/home/oracle/DB_Check/dg_durum.sql'
