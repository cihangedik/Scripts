
##. /home/orampdb/grid.env

crs_stat -t
crsctl check crs
srvctl status listener
srvctl status ASM
