
set linesize 2000
set pagesize 2000

  SELECT start_time,
         input_type,
         status,
         ROUND (elapsed_seconds / 3600, 1) time_hr
    FROM v$rman_backup_job_details
   WHERE START_TIME > SYSDATE - 7 
ORDER BY start_time DESC;

exit
