--tti '    db_recovery_file_dest_size'
set pagesize 1000 line 200
col "db_recovery_file_dest" for a32;
col size_m   for 999,999,999;
col used_m   for 999,999,999;
col pct_used for 999;
select name "db_recovery_file_dest",ceil(space_limit/1024/1024) ToplamMB, ceil( space_used /1024/1024) DoluMB,
decode( nvl(space_used, 0),0,0,ceil(( space_used /space_limit) * 100)) Yuzde
from v$recovery_file_dest
order by 1;
exit;