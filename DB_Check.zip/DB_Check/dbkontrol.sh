#!/bin/bash
xdb='KTHR
'
for i in $xdb
do
export ORACLE_SID=$i
export ORACLE_HOME=/erp/oraprod/kthrdb/10.2.0
export GRID_HOME=/u01/app/12.1.0.2/grid
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH:$GRID_HOME/bin
export ORACLE_UNQNAME=$i

firma='KUVEYT TURK'
raporpath=/home/oracle/DB_Check/raporlar/
tarih=$(date +"%Y-%m-%d")
rapor=$raporpath$firma'_'$ORACLE_UNQNAME'_GunlukKontrol_'$tarih'.html'
rm -rf $rapor 

echo "<a href='"https://www.gantek.com"'><left><img src='"https://portal.gantek.com/Content/img/gantek_logo.jpg"'width='"200"' height="'100'"</left></a><p/>">$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE ARCHIVELOG MOD</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database_logmod.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE SIZE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database_size.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='1700' border='4'bordercolor='grey'><tr><td colspan="3" align='middle' ><b>TOP WAIT EVENTS</b></td></tr><tr><tbody><td align='middle' width="50"><pre><b>SON 5 DAKIKA </b></pre></td><td align='middle' width="50"><pre><b>SON 10 DAKIKA </b></pre></td><td align='middle' width="50" ><pre><b>SON 20 DAKIKA </b></pre></td></tr><tr><tbody><td width="50" VALIGN="top" ><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/top_wait_events.sql)</pre></td><td width="50" VALIGN="top"><pre>$(sqlplus / as sysdba @/home/oracle/DB_Check/top_wait_events10.sql)</pre></td><td width="50" VALIGN="top"><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/top_wait_events20.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>TABLESPACE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/tablespace.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>BACKUP</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/backup.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_1 DISK STATUS</th></tr><tr><tbody><td><pre> $(df -h)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_2 DISK STATUS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/node2_disk.sh)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_1 MEMORY</th></tr><tr><tbody><td><pre> $(free -m)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_2 MEMORY</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/node2_memory.sh)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_1 LISTENER STATUS</th></tr><tr><tbody><td><pre> $(lsnrctl status)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_2 LISTENER STATUS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/node2_listener.sh)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>ASM DISK</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/asm_disk.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>JOB ERROR'S</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/hatali_job.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>LOG SWITCH FREQUENCY MAP</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/log_switch.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DB RECOVRY FILE DEST SIZE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/db_recovery_file_dest_size.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>SYSAUX</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/sysaux.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_1 ALERTLOG ERROR</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/alert.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>NODE_2 ALERTLOG ERROR</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/node2_alert.sh)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE PROFILE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/profile.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>CLUSTER SERVICE</th></tr><tr><tbody><td><pre> $(crsctl status res -t)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>CLUSTER SERVICE</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/cluster.sh)</pre></td></tr></tbody></table>">>$rapor

#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>CHANGE SQL PLAN</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/change_sql_plan.sql)</pre></td></tr></tbody></table>">>$rapor

################# DATAGUARD CHECK

#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD DISK STATUS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_disk.sh $i)</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD MEMORY</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_memory.sh)</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD ASM DISK STATUS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_asm_disk.sh)</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD LAG STATUS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_durum.sh)</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD PROCESS</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_durum_process.sh )</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD LISTENER</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_listener.sh)</pre></td></tr></tbody></table>">>$rapor
#echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATAGUARD ALERTLOG ERROR</th></tr><tr><tbody><td><pre> $(sh /home/oracle/DB_Check/dg_alert.sh)</pre></td></tr></tbody></table>">>$rapor



################# SEND EMAIL 

#MAIL_PROG=
#MAIL_SERVER=
#MAIL_PORT=25
#MAIL_FROM='MUSTERIADI VERITABANI'
#FROM_ADDR=
#m=cihan.gedik1@ibm.com
#$MAIL_PROG -f "$MAIL_FROM <$FROM_ADDR>" -t $m -o username=noreply@rihmym.com -o password=PxiX1pSJVc -u "GUNLUK VERITABANI RAPORU" -s $MAIL_SERVER:$MAIL_PORT -m "VERITABANI GUNLUK KONTROL RAPORU EKTEDIR." -a $rapor;

done

echo "<style>table{border:1px solid #b5b5b5; margin-bottom:30px;}th{background:#b5b5b5; border:none; padding:5px;}td{border:none; background:#e6e6e6; padding:5px;}</style>">>$rapor
