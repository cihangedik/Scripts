ssh 10.235.40.2 'hostname ; free -m'
