
set linesize 2000
set pagesize 2000

                   
  SELECT owner,
         job_name,
         status,
         LOG_DATE,
         ERROR#,
         (  EXTRACT (SECOND FROM run_duration)
          + EXTRACT (MINUTE FROM run_duration) * 60
          + EXTRACT (HOUR FROM run_duration) * 3600
          + EXTRACT (DAY FROM run_duration) * 3600 * 24)
            SECONDS, ADDITIONAL_INFO
    FROM dba_scheduler_job_run_details
   WHERE LOG_DATE > SYSDATE - 2 AND status != 'SUCCEEDED'
ORDER BY 1 ASC, 4 DESC;

exit

