set line 150 
set pagesize 1000

select * from dba_profiles;

exit
