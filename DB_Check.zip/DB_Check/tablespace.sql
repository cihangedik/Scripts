set pagesize 1000 linesize 180
tti 'Tablespace Doluluk Durumu'
col "TOPLAM(MB)"  for 99,999,999.999
col "DOLU(MB)"    for 99,999,999.999
col "BOS(MB)"     for 99,999,999.999 
col "Artabilir(MB)" for 99,999,999.999 
col "ORAN1 %"     for 999.99
col "ORAN2 %"     for 999.99
col "NOTO"        for 9999
col "OTO"         for 999
select d.tablespace_name "ADI", 
       d.contents "TIPI",
       nvl(a.bytes /1024/1024,0) "TOPLAM(MB)",
       nvl(a.bytes - nvl(f.bytes,0),0)/1024/1024 "DOLU(MB)",
       nvl(f.bytes,0)/1024/1024 "BOS(MB)",
       nvl((a.bytes - nvl(f.bytes,0))/a.bytes * 100,0)  "ORAN1 %",
       nvl(a.ARTACAK,0)/1024/1024 "Artabilir(MB)",
       nvl((a.bytes - nvl(f.bytes,0))/ (a.bytes + nvl(a.ARTACAK,0)) * 100,0)  "ORAN2 %",
       a.NOTO, a.OTO
  from sys.dba_tablespaces d,
       (select tablespace_name, sum(bytes) bytes,
               sum(decode(autoextensible,'YES',MAXbytes - bytes,0 )) ARTACAK,
               count(decode(autoextensible,'NO',0)) NOTO,
               count(decode(autoextensible,'YES',0)) OTO
            from dba_data_files
          group by tablespace_name) a,
       (select   tablespace_name, sum(bytes) bytes
            from dba_free_space
        group by tablespace_name) f
 where d.tablespace_name = a.tablespace_name(+)
  and d.tablespace_name = f.tablespace_name(+)
  and NOT (d.extent_management like 'LOCAL'and d.contents like 'TEMPORARY')
UNION ALL
select d.tablespace_name "ADI",
       d.contents "TIPI",
       nvl(a.bytes /1024/1024,0) "TOPLAM(MB)",
       nvl(t.bytes,0)/1024/1024  "DOLU(MB)",
       nvl(a.bytes - nvl(t.bytes,0),0)/1024/1024 "BOS(MB)",
       nvl(t.bytes/a.bytes * 100,0) "ORAN1 %",
       nvl(a.ARTACAK,0)/1024/1024 "Artabilir(MB)",
       nvl(t.bytes/(a.bytes + nvl(a.ARTACAK,0)) * 100,0) "ORAN2 %", a.NOTO, a.OTO
  from sys.dba_tablespaces d,
       (select tablespace_name, sum(bytes) bytes,
               sum(decode(autoextensible,'YES',MAXbytes - bytes,0 )) ARTACAK,
               count(decode(autoextensible,'NO',0)) NOTO,
               count(decode(autoextensible,'YES',0)) OTO
            from dba_temp_files
        group by tablespace_name) a,
        (select tablespace_name, sum(bytes_used) bytes   
            from v$temp_extent_pool
        group by tablespace_name) t
 where d.tablespace_name = a.tablespace_name(+)
  and d.tablespace_name = t.tablespace_name(+)
  and d.extent_management like 'LOCAL'
  and d.contents like 'TEMPORARY%'
  order by 8 desc;
exit;


ALTER TABLESPACE APPS_TS_INTERFACE ADD DATAFILE '/u01/oracle/prod/db/data/a_int04.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE APPS_TS_ARCHIVE ADD DATAFILE '/u01/oracle/prod/db/data/a_archive03.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE APPS_TS_TX_IDX ADD DATAFILE '/u01/oracle/prod/db/data/a_txn_ind09.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE APPS_TS_QUEUES ADD DATAFILE '/u01/oracle/prod/db/data/a_queue03.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE SYSAUX ADD DATAFILE '/u01/oracle/prod/db/data/sysaux03.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;

ALTER TABLESPACE APPS_TS_SUMMARY ADD DATAFILE '/u01/oracle/prod/db/data/a_summ02.dbf' SIZE 5G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE APPS_TS_MEDIA ADD DATAFILE '/u01/oracle/prod/db/data/a_media03.dbf'  SIZE 5G AUTOEXTEND ON MAXSIZE 10G;



ALTER TABLESPACE TEMP1 ADD TEMPFILE '/u01/oracle/prod/db/data/temp01_01.dbf' SIZE 3G AUTOEXTEND ON MAXSIZE 10G;
ALTER TABLESPACE TEMP2 ADD TEMPFILE '/u01/oracle/prod/db/data/temp02_01.dbf' SIZE 3G AUTOEXTEND ON MAXSIZE 10G;

/u01/oracle/prod/db/data/temp01.dbf
/u01/oracle/prod/db/data/temp02.dbf


select TS#,NAME from v$tablespace;


select name from v$datafile where TS#=387; 
select name from v$datafile where TS#=384; 
select name from v$datafile where TS#=383; 

select name from v$datafile where TS#=0; ----APPS_TS_TX_IDX
select name from v$datafile where TS#=389; ----APPS_TS_TX_IDX


select name from v$tempfile where TS#=284; ----TMP1
select name from v$tempfile where TS#=394; ----TMP2



 select TS#,NAME from v$tablespace;

       TS# NAME
---------- ------------------------------
         0 SYSTEM
       392 SYSAUX
         1 CTXD
       381 APPS_TS_TX_DATA
       382 APPS_TS_TX_IDX
         2 OWAPUB
       388 APPS_TS_QUEUES
       390 ODM
       391 OLAP
       393 APPS_TS_TOOLS
       383 APPS_TS_SEED

       TS# NAME
---------- ------------------------------
       384 APPS_TS_INTERFACE
       307 PORTAL
       368 APPS_UNDOTS1
       385 APPS_TS_SUMMARY
       386 APPS_TS_NOLOGGING
       387 APPS_TS_ARCHIVE
       389 APPS_TS_MEDIA
       284 TEMP1
       394 TEMP2


