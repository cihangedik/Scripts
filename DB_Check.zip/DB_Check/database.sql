

set linesize 2000
set pagesize 2000

SELECT i.host_name,       i.instance_name,       d.name,            TO_CHAR (i.startup_time,
'DD-MM-YYYY  HH24:MI:SS') startup_time, d.open_mode, status,database_status ,database_role 
FROM gv$instance i, gv$database d where I.inst_id=D.inst_id;

exit

