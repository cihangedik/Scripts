#!/bin/bash
xdb='ARASEXA1
'
for i in $xdb
do
export ORACLE_SID=$i
export ORACLE_HOME=/u01/app/oracle/product/12.1.0.2/dbhome_1
export GRID_HOME=/u01/app/12.1.0.2/grid
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$PATH:$GRID_HOME/bin
export ORACLE_UNQNAME=$i

firma='ARAS_KARGO'
raporpath=/home/oracle/DB_Check/raporlar/
tarih=$(date +"%Y-%m-%d")
rapor=$raporpath$firma'_'$ORACLE_UNQNAME'_GunlukKontrol_Style_'$tarih'.html'
rm -rf $rapor 

echo "<a href='"https://www.ibm.com"'><left><img src='"https://upload.wikimedia.org/wikipedia/commons/5/51/IBM_logo.svg"'width='"200"' height="'100'"</left></a><p/>">$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE ARCHIVELOG MOD</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database_logmod.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>DATABASE SIZE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/database_size.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='"1500"' border='"4"'bordercolor='"black" '><tr><th bgcolor='"white"'>TABLESPACE</th></tr><tr><tbody><td><pre> $(sqlplus -s / as sysdba @/home/oracle/DB_Check/tablespace.sql)</pre></td></tr></tbody></table>">>$rapor
echo "<table width='1700' border='4'bordercolor='red'><tr><td colspan="3" align='middle' ><b>TOP WAIT EVENTS</b></td></tr><tr><tbody><td align='middle' width="50"><pre><b>SON 5 DAKIKA </b></pre></td><td align='middle' width="50"><pre><b>SON 10 DAKIKA </b></pre></td><td align='middle' width="50" ><pre><b>SON 20 DAKIKA </b></pre></td></tr><tr><tbody><td width="50" VALIGN="top" ><pre> $(sqlplus -s / as sysdba @$SCRIPT_HOME/top_wait_events.sql)</pre></td><td width="50" VALIGN="top"><pre>$(sqlplus / as sysdba @$SCRIPT_HOME/top_wait_events10.sql)</pre></td><td width="50" VALIGN="top"><pre> $(sqlplus -s / as sysdba @$SCRIPT_HOME/top_wait_events20.sql)</pre></td></tr></tbody></table>">>$RAPOR_PATH/$KURUM-$DB_NAME-GunlukKontrol-$(date '+%d.%m.%y').html
echo "<table width='1700' border='4'bordercolor='red'><tr><td colspan="3" align='middle' ><b>TOP WAIT EVENTS</b></td></tr><tr><tbody><td align='middle' width="50"><pre><b>SON 5 DAKIKA </b></pre></td><td align='middle' width="50"><pre><b>SON 10 DAKIKA </b></pre></td><td align='middle' width="50" ><pre><b>SON 20 DAKIKA </b></pre></td></tr><tr><tbody><td width="50" VALIGN="top" ><pre> $(sqlplus -s / as sysdba @$SCRIPT_HOME/top_wait_events.sql)</pre></td><td width="50" VALIGN="top"><pre>$(sqlplus / as sysdba @$SCRIPT_HOME/top_wait_events10.sql)</pre></td><td width="50" VALIGN="top"><pre> $(sqlplus -s / as sysdba @$SCRIPT_HOME/top_wait_events20.sql)</pre></td></tr></tbody></table>">>$RAPOR_PATH/$KURUM-$DB_NAME-GunlukKontrol-$(date '+%d.%m.%y').html


################# SEND EMAIL 

#MAIL_PROG=
#MAIL_SERVER=
#MAIL_PORT=25
#MAIL_FROM='MUSTERIADI VERITABANI'
#FROM_ADDR=
#m=cihan.gedik1@ibm.com
#$MAIL_PROG -f "$MAIL_FROM <$FROM_ADDR>" -t $m -o username=noreply@rihmym.com -o password=PxiX1pSJVc -u "GUNLUK VERITABANI RAPORU" -s $MAIL_SERVER:$MAIL_PORT -m "VERITABANI GUNLUK KONTROL RAPORU EKTEDIR." -a $rapor;

done

echo "<style>table{border:1px solid #b5b5b5; margin-bottom:30px;}th{background:#b5b5b5; border:dotted; padding:5px;}td{border:none; background:#e6e6e6; padding:5px;}</style>">>$rapor
