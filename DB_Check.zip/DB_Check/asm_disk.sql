
set linesize 2000
set pagesize 2000

SELECT group_number,
       name,
       TYPE,
       total_mb,
       free_mb
  FROM v$asm_diskgroup;

exit

