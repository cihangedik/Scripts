ssh 172.31.211.202  'hostname ; free -m'
