
set linesize 2000
set pagesize 2000

select sum(bytes / (1024*1024)) "DB Size in MB" from dba_segments;

exit

