

root -c ssh exampceladm01

#'hostname ; cellcli -e list physicaldisk detail | grep status'
