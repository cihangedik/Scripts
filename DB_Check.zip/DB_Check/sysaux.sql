
set linesize 2000
set pagesize 2000

select segment_name,bytes/1024/1024 from dba_segments where segment_name in ('WRI$_OPTSTAT_HISTHEAD_HISTORY','WRI$_OPTSTAT_HISTGRM_HISTORY');

exit
