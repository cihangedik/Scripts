

SET MARKUP HTML ON SPOOL ON PREFORMAT OFF ENTMAP ON
 
BODY "TEXT='#FF00F'" 
TABLE "BORDER='2' width=''"

set linesize 150
set pagesize 150
set heading on
spool /home/oracle/scripts/rapor.html

set echo on
--------------------startup zamani----------------------
set echo off

---------------------------------------
--Select 'DATABASE MONITORING' from dual;  
---------------------------------------
SELECT i.host_name,
       i.instance_name,
       d.name,
       d.open_mode,
       i.startup_time
  FROM v$instance i, v$database d;

set echo on
-------------------tablespace durumu----------------------
set echo off

---------------------------------------
--Select 'TABLESPACE USAGE' from dual;  
---------------------------------------
SELECT a.tablespace_name,
           ROUND (a.bytes_alloc / 1024 / 1024) allocated_MB,
           ROUND (NVL (b.bytes_free, 0) / 1024 / 1024) free_MB,
           ROUND ( (a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024) used_MB,
           ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_Free,
           100 - ROUND ( (NVL (b.bytes_free, 0) / a.bytes_alloc) * 100) Pct_used,
           ROUND (maxbytes / 1048576) MAX_MB
  FROM (  SELECT f.tablespace_name,
                                 SUM (f.bytes) bytes_alloc,
                                 SUM (DECODE (f.autoextensible, 'YES', f.maxbytes, 'NO', f.bytes))  maxbytes
                        FROM dba_data_files f
                GROUP BY tablespace_name) a,
           (  SELECT f.tablespace_name, SUM (f.bytes) bytes_free
                        FROM dba_free_space f
                GROUP BY tablespace_name) b
 WHERE a.tablespace_name = b.tablespace_name(+)
UNION ALL --Temp Tablespaces
  SELECT h.tablespace_name,
                 ROUND (SUM (h.bytes_free + h.bytes_used) / 1048576) allocated_MB,
                 ROUND (SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / 1048576) free_MB,
                 ROUND (SUM (NVL (p.bytes_used, 0)) / 1048576) used_MB,
                 ROUND ((  SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100) Pct_Free,
                   100  - ROUND ((  SUM ( (h.bytes_free + h.bytes_used) - NVL (p.bytes_used, 0)) / SUM (h.bytes_used + h.bytes_free)) * 100)  pct_used,
                 ROUND (SUM (f.maxbytes) / 1048576) MAX_MB
        FROM sys.v_$TEMP_SPACE_HEADER h,
                 sys.v_$Temp_extent_pool p,
                 dba_temp_files f
   WHERE     p.file_id(+) = h.file_id
                 AND p.tablespace_name(+) = h.tablespace_name
                 AND f.file_id = h.file_id
                 AND f.tablespace_name = h.tablespace_name
GROUP BY h.tablespace_name
ORDER BY 3 ASC;


set echo on
-------------------Database Size----------------------
set echo off

select sum(bytes / (1024*1024)) "DB Size in MB" from dba_segments;




set echo on
----------------------ASM DISK DURUMU------------------------
set echo off


-----------------------------------------
--Select 'ASM DISK GROUPS' from dual;
------------------------------------------
SELECT group_number,
       name,
       TYPE,
       total_mb,
       free_mb
  FROM v$asm_diskgroup;

set echo on
--------------------BACKUP DURUMU----------------------
set echo off

-----------------------------------------
--Select 'BACKUP SUMMARY' from dual;
------------------------------------------
  SELECT start_time,
         input_type,
         status,
         ROUND (elapsed_seconds / 3600, 1) time_hr
    FROM v$rman_backup_job_details
   WHERE START_TIME > SYSDATE - 20
ORDER BY start_time DESC;

set echo on
----------------------HATALI BITEN JOBLAR----------------------
set echo off
                                                                   
-----------------------------------------
--Select 'SCHEDULED_JOBS DETAILS' from dual;
------------------------------------------
                   
  SELECT owner,
         job_name,
         status,
         LOG_DATE,
         ERROR#,
         (  EXTRACT (SECOND FROM run_duration)
          + EXTRACT (MINUTE FROM run_duration) * 60
          + EXTRACT (HOUR FROM run_duration) * 3600
          + EXTRACT (DAY FROM run_duration) * 3600 * 24)
            SECONDS, ADDITIONAL_INFO
    FROM dba_scheduler_job_run_details
   WHERE LOG_DATE > SYSDATE - 2 AND status != 'SUCCEEDED'
ORDER BY 1 ASC, 4 DESC;


set echo on
-------------------SON 1 GUNLUK ALERT LOG HATALARI----------------------
set echo off

---------------------------------------
--Select 'ALERT.LOG last 2 days error' from dual;  
---------------------------------------

---version 1
SELECT SUBSTR (MESSAGE_TEXT, 1, 300) MESSAGE_TEXT,
       TO_CHAR (ORIGINATING_TIMESTAMP, 'DD-MON-YYYY HH24:MI:SS') Occur_date
  FROM X$DBGALERTEXT
 WHERE     (MESSAGE_TEXT LIKE '%ORA-%' OR UPPER (MESSAGE_TEXT) LIKE '%ERROR%'  OR UPPER (MESSAGE_TEXT) LIKE '%ALTER SYSTEM%' OR UPPER (MESSAGE_TEXT) LIKE '%ALTER DATABASE%')
       AND CAST (ORIGINATING_TIMESTAMP AS DATE) > SYSDATE - 1;
---version 2 - count   
SELECT SUBSTR (MESSAGE_TEXT, 1, 300) MESSAGE_TEXT, COUNT (*) cnt
    FROM X$DBGALERTEXT
   WHERE     (MESSAGE_TEXT LIKE '%ORA-%' OR UPPER (MESSAGE_TEXT) LIKE '%ERROR%')
         AND CAST (ORIGINATING_TIMESTAMP AS DATE) > SYSDATE - 1 
GROUP BY SUBSTR (MESSAGE_TEXT, 1, 300);


---------------------------------------
--Select '....Kolay gelsin....' from dual;  
---------------------------------------

spool off;
exit

