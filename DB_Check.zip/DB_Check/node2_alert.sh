ssh arasdbadm02 'hostname ; . /home/oracle/.bash_profile ; sqlplus -s / as sysdba @/home/oracle/DB_Check/alert.sql'
