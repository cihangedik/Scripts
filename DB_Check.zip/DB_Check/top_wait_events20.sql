 col wait_class for a30
 col event for a40
 set feed off
 set line 200
set pagesize 2000
SELECT NVL(a.event, 'ON CPU') AS event,
       COUNT(*) AS total_wait_time
FROM   v$active_session_history a
WHERE  a.sample_time > SYSDATE - 20/(24*60) -- 10 mins
GROUP BY a.event
ORDER BY total_wait_time DESC;
exit;