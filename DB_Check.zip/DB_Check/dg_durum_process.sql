
set line 2000
set pagesize 2000

select process, client_process,thread#,sequence#,status from v$managed_standby;

exit
