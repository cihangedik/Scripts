
set line 2000
set pagesize 2000


select name,db_unique_name,platform_name,log_mode from v$database;

exit
