
set line 200
select * from v$dataguard_stats;

exit
