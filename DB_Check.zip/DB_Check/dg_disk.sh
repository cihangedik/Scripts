ssh 10.235.40.2 'hostname ; df -h'
