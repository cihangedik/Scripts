
ssh 172.31.211.202 'hostname ; . /home/oracle/.bash_profile ; df -h'
