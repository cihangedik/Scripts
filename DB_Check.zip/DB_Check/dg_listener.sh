ssh 10.235.40.2 'hostname ; . /home/oracle/.bash_profile ; lsnrctl status '
